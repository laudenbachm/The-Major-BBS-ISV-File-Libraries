/***************************************************************************
 *                                                                         *
 *   MR_BUILD.C                                                            *
 *                                                                         *
 *   Copyright (C) 1994 Mountain Rose Multi Media All Rights Reserved.     *
 *                                                                         *
 *                                                 - B.Rozenberg   2/24/94 *
 *                                                                         *
 ***************************************************************************/

#include "gcomm.h"
#include "majorbbs.h"
#include "filexfer.h"
#include "reserve.h"
#include "galfilh.h"

DFAFILE *libbb;               /* LIB database file handle                   */
struct libdisk libbuf;

VOID main(INT argc, CHAR *argv[])
{
  static GBOOL keys_only=TRUE;

  initvid();
  keys_only=((argc==2) && sameas(argv[1],"KEYS"));
  libbb=dfaOpen("GALFILL2.DAT",sizeof(struct libdisk),NULL);
  if(dfaQueryLO(0)) {
    do {
      dfaAbsRec(&libbuf,0);
      if (!keys_only) {
	fprintf(stdout,"\n\n===========================================================================");
	fprintf(stdout,"\nLIBRARY: %-10s %s",libbuf.lib.libname,libbuf.lib.libdesc);
	fprintf(stdout,"\n===========================================================================");
	fprintf(stdout,"\nLibrary Operator: %s",libbuf.lib.primary);
	fprintf(stdout,"\n      # of Files: %ld",libbuf.lib.numfiles);
	fprintf(stdout,"\n      # of Bytes: %ld",libbuf.lib.totbytes);
	fprintf(stdout,"\nDownload Royalty: %d percent",libbuf.lib.royal);
	fprintf(stdout,"\n  Max # of Files: %ld",libbuf.lib.maxfil);
	fprintf(stdout,"\n  Max # of Bytes: %ld",libbuf.lib.maxbyt);
	fprintf(stdout,"\n Max Upload Size: %ld",libbuf.lib.maxbup);
	if (strlen(libbuf.lib.path))  fprintf(stdout,"\n        Alt Path: %s",libbuf.lib.path);
	fprintf(stdout,"\n    File Charges: %ld",libbuf.lib.dlchge);
	fprintf(stdout,"\n      Kb Charges: %ld",libbuf.lib.kdlchge);
      }
      fprintf(stdout,"\n     Visible Key: %s",libbuf.lib.keyreq);
      fprintf(stdout,"\n      Lib-Op Key: %s",libbuf.lib.libop);
      fprintf(stdout,"\nAuto-Approve Key: %s",libbuf.lib.autoap);
      fprintf(stdout,"\n    Download Key: %s",libbuf.lib.dlkey);
      fprintf(stdout,"\n      Upload Key: %s",libbuf.lib.ulkey);
      fprintf(stdout,"\n   Overwrite Key: %s",libbuf.lib.overw);
    }while (dfaQueryNX());
  }
  dfaClose(libbb);
  clsvid();
}
