/* rtf2html.c */

#include    <stdio.h>
#include    <malloc.h>
#include    <io.h>

#include    "rtftohtm.h"


/**************************************/

main(int argc, char* argv[]){
    char    arg[256];
    char*   ofile;
    long    rc = 0;
    char*   buf;
    unsigned    bl = 20000;
    
    if (argc==1){
        buf = malloc(bl);
        // no arguments: ask user the input filename.
        puts("Give an input filename");
        rc = RTFtoHTM(gets(arg),0,buf,bl);
        puts(buf);
    }    
    if (argc>2){
        _wsetexit(_WINEXITNOPERSIST);
        // both arguments: do the conversion from file to file.
        rc = RTFtoHTM(argv[1],0,argv[2],0);
        ofile = argv[2];
    }    
    else{
        buf = malloc(bl);
        // one argument: do the conversion from file to buffer.
        // puts the buffer to the screen.
        rc = RTFtoHTM(argv[1],0,buf,bl);
        puts(buf);
    }
    
            
    return 0;
}
