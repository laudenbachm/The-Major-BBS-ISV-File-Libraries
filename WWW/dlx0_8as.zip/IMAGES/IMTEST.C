#include <stdio.h>
#include "image.h"

int main(int argc, char *argv[]) {
  char fname[81];
  int mode;
  int i;
	while(1) {
		printf("Image viewer test\n");
  	printf("Enter a filename and a mode # separated by a space.\n");
  	printf("Modes:\n");
  	for (i=0; (i<image_modes_total); i++) {
  		printf("%d) %s\n", i, image_mode_names[i]);
  	}
  	printf("Filename and mode: ");
		scanf("%s %d", fname, &mode);
		image_viewer(fname, mode);
  }
	return 0;
}
