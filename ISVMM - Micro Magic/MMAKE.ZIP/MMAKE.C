/*
** Revision history at the end of this source
*/

#include <stdio.h>
#include <string.h>
void main( int argc, char **argv ) {
  FILE *fmap,*fibm,*fans,*fasc;
  char buf[32];
  int ascii[256], c, oldc, nextc, lastc=0, curc=0;
  char *ansistop={"HfABCDRsuJKmhlp"};
  char ascii_string[256];
  int i,l, ansistopflag=0, clsflag=0;


  /*
  ** check for a valid command line
  */

  if( argc != 2 ) {
    printf( "\007\n" );
    puts( "MMAKE v1.1  (940221)  Copyright 1994-1996 Keith Ford" );
    puts( "" );
    puts( "MMAKE will take a menu file and create additional menu files" );
    puts( "which will not contain ANSI escape sequences and/or IBM special" );
    puts( "characters.  You can now build XXX.IBM then have MMAKE build" );
    puts( "XXX.ANS and XXX.ASC for you." );
    puts( "" );
    puts( "Usage:  MMAKE <filename>.IBM" );
    puts( "" );
    exit( 0 );
    }


  /*
  ** load character map
  ** (leave 0xFF & 0x4E for Menu Markers & text variables)
  */

  for( i=0; i<256; i++) ascii[i]=i;
  for( i=127; i<255; i++) ascii[i]='-';
  ascii[255]=255;
  ascii[78]=78;

  l=strlen( ansistop );

  /*
  ** open needed files
  */
 
  fibm = fopen( argv[1], "r" );
  if( !fibm ) {
    printf( "ERROR: could not open %s\n", argv[1] );
    exit( 1 );
    }
  strcpy( buf, argv[1] );
  *(strchr( buf, '.' )) = '\0';
  strcat( buf, ".ans" );
  fans = fopen( buf, "w" );
  if( !fans ) {
    printf( "ERROR: could not open %s\n", buf );
    fclose( fibm );
    exit( 1 );
    }
  *(strchr( buf, '.' )) = '\0';
  strcat( buf, ".asc" );
  fasc = fopen( buf, "w" );
  if( !fans ) {
    printf( "ERROR: could not open %s\n", buf );
    fclose( fibm );
    fclose( fans );
    exit( 1 );
    }

  do {
    oldc = getc( fibm );

    /*
    ** process IBM special characters
    */

    c = ascii[oldc];


    /*
    ** for ANS, this is it
    */

    fprintf( fans, "%c", c );


    /*
    ** process ANSI escape sequences
    ** and standard printable characters
    */

    if( oldc == 27 ) {
      nextc = getc( fibm );
      if( nextc == '[' ) {
        fprintf( fans, "%c", nextc );
	ansistopflag=0;
	while( 1 ) {
	  oldc = getc( fibm );
	  if( clsflag ) {
	    if( oldc == 'J' )
	      fprintf( fasc, "" );
	    clsflag = 0;
	    }
	  if(( oldc == '2' )&&( !clsflag ))
	    ++clsflag;
          fprintf( fans, "%c", oldc );
	  for( i=0; i<l; i++)
	    if( oldc == ansistop[i] ) {
	      ansistopflag=1;
	      break;
	      }
	  if( ansistopflag ) {
	    break;
	    }
	  }
	}
      else {
	ungetc( nextc, fibm );
	ascii_string[curc++]=c;
	if ((c=='\r') || (c=='\n') || (oldc==EOF)) {
	  if (oldc==EOF) lastc+=2;
	  ascii_string[lastc] = '\0';
          fprintf( fasc, "%s%c", ascii_string, c );
	  ascii_string[0] = lastc = curc = 0;
	  }
	else if ((c!=' ') && (c!='	')) {
	  lastc=curc;
	  }
	}
      }
    else {
      ascii_string[curc++] = c;
      if ((c=='\r') || (c=='\n') || (oldc==EOF)) {
	if (oldc==EOF) lastc+=2;
        ascii_string[lastc] = '\0';
        fprintf( fasc, "%s%c", ascii_string, c );
        ascii_string[0] = lastc = curc = 0;
        }
      else if ((c!=' ') && (c!='	')) {
        lastc=curc;
        }
      }
    }
  while( oldc != EOF );

  fclose( fibm );
  fclose( fans );
  fclose( fasc );
  }


/*
** 940221 - Handle Menu Markers (0xFF)
*/
