#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main (int argc, char **argv) {
  time_t timer;
  struct tm *tblock;
  timer = time (NULL);
  tblock = localtime (&timer);
  if ((argc == 2) && (atoi(argv[1]) == tblock->tm_mday)) return (1);
  else return (0);
}
