// Yeah, this is a simple program, but I've found it useful.
// Especially when I want to see how long different parts of
// my cleanup are taking.  Enjoy!  -kef/MM-

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void main (void) {
  time_t timer;
  struct tm *tblock;
  timer = time(NULL);
  tblock = localtime(&timer);
  fprintf(stdout,"%s",asctime(tblock));
}
