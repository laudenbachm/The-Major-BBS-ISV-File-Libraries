Mega Market 1.08d Patch
AFTER you have installed the Market,
place this file in your wgserv directory,
and type "pkunzip new108d.zip -d"
The "-d" option is vital to success!
06/16/96