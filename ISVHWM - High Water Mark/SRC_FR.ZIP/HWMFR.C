/*
*********************************************************************
* hwmfr.c
* "Function Replacement"
* This is an adaptation of Bill Sobel's (Humanware) and D Brien's
* use of "function * thunking". This allows a function to be replaced
* in memory, and * call a new function. By use of some macro's, the
* old/new function * can be called at will.
*********************************************************************
* Usage:
* #include HWMFR.INC at the top of your source module. HWMFR.C is
* usually included at the bottom of your source module.
*
* Call fr_Setup in your INIT module routine, to get the addresses
* of the functions it needs. If you need to wait until another module
* comes online, then RTKICK for 1 second and then get the addresses.
*
* Your replacement function will be called instead of the old
* version; if you need to call the old function, then use
* FR_THUNKOLD and then call it. Make sure to use FR_THUNKNEW when
* you're done.
*********************************************************************
*/
#include "hwmcomp.h"
#include "hwmfr.inc"

/*
*********************************************************************
* fr_Setup
* An adaptation of Bill Sobel's, dbrien's and other's "thunk" code.
* This is used to replace one function with another, while still allowing
* the original function to be used.
* This particular function is used for the "setup" of the thunk control
* structures.
*
* Parameters
* ----------
*	Thunk - this is a structure that will contain the original
*		function's address, etc.
*	OldFuncAddr - this is the address of the function we are replacing.
*	NewFuncAddr - this is the address of the function that we want
*		to replace with. It will overwrite the old function's info.
*
* Returns
* -------
*	TRUE if function replacement was made.
*********************************************************************
*/
int EXPORT fr_Setup
(
	FR_THUNK_STRUCT 	*Thunk,
	PPFN 				OldFuncAddr,
	PPFN 				NewFuncAddr
)
{
	int					RetValue;
	SEL					Selector;

	// first, check that we have valid setup info
	if
	(
		(Thunk == NULLPTR)
		OR
		(OldFuncAddr == NULLPTR)
		OR
		(NewFuncAddr == NULLPTR)
	)
		return (FALSE);

	// create an alias for the program data memory, so that we
	// can manipulate it as data.
	RetValue = DosCreateDSAlias (SELECTOROF(OldFuncAddr), &Selector);
	if (RetValue != 0)
	{
		shocst ("HWMFR cannot create old function data", "");
		return (FALSE);
	}
	// save the old function address
	Thunk->OldFuncAddr = MAKEP (Selector, OFFSETOF(OldFuncAddr));

	// save the original function's program code to our structure,
	// so we can replace it later
	memcpy (&Thunk->OldFuncCodePrefix[0], Thunk->OldFuncAddr, 5);

	// over-write the original function with the instructions
	// to "jump far" to the address of our new function.
	Thunk->NewFuncCodePrefix[0] = 0xea;				// far jump
	memcpy (&Thunk->NewFuncCodePrefix[1], &NewFuncAddr, 4);

	// done
	return (TRUE);
}
